# DarkFly-Tool
The latest version of DarkFly tool V.4.0

DarkFly now is: <a href="https://github.com/Ranginang67/DarkFly-2019.1">DarkFly-2019.1</a> (generation of DarkFly-tool) Try it.

information:

DarkFly-Tool is an installation tool for installing tools. this tool makes it easy for you. so you don't need to type git clone or look for the github repository. You only have to choose the number. which tool you want to install. there are 530 tools ready for intall. and for those of you who like to have fun. there are 7 SMS spam tools that are ready to use, you just need to choose spam to use the target number. there is a tocopedia DLL, 

install:

**Termux:**

* `pkg install python2`
* `pkg install git`
* `git clone https://github.com/Ranginang67/DarkFly-Tool`
* `cd DarkFly-Tool`
* `python2 install.py`

```
1.if installed is complite, use command
$cd
2.then run it
$DarkFly
```

**NOTE:**
```
if python2 install.py is not allowed or fail, Use this
$chmod +x install.py
$python2 install.py
```
**how to update:**

for update this tool, just do the reinstallation, the first way is to install the Darkfly tools, by reinstalling, the old file will be deleted and replaced with the new one installed.
# note
```
the DarkFly tools on linux does not working
```

# support me
<a href="https://www.youtube.com/channel/UCNMD5U02GFeWLqmrl_XSPGQ"><img src="https://img.shields.io/badge/subcribe-YouTube-red.svg">
